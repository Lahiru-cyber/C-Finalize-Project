Usage:

   A TextBox by default value to hint that and have some features such as Math Parser, Numeric Mode, Thousands Separator and etc.