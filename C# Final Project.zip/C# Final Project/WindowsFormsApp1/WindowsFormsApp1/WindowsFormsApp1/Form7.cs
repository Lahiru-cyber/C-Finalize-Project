﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

            string expire = txt2.Text;
            string cnumber = txt1.Text;
            string cvcNum = txt3.Text;


            if (cnumber == "")
            {
                MessageBox.Show("Please enter card number!");
            }
            else if (cnumber.Length != 16)
            {
                MessageBox.Show("Please enter a valid card number!");
            }
            else if (expire == "")
            {
                MessageBox.Show("Please enter expiration date!");
            }
            else if (cvcNum == "")
            {
                MessageBox.Show("Please enter CVC number!");
            }
            else if (cvcNum.Length != 3)
            {
                MessageBox.Show("Please enter a valid CVC number!");
            }
            else
            {

                string numString = txt1.Text;
                long number1 = 0;
                bool canConvert = long.TryParse(numString, out number1);

                string numString2 = txt3.Text;
                long number2 = 0;
                bool canConvert2 = long.TryParse(numString2, out number2);

                if (canConvert != true)
                {
                    MessageBox.Show("Card number cannot letters!");
                }
                else if (canConvert2 != true)
                {
                    MessageBox.Show("CVC number cannot letters!");
                }
                else
                {
                    MessageBox.Show("your Payment is Successfully!");
                    Application.Exit();
                }

                /*
                try
                {
                    int cnum = int.Parse(txt1.Text);
                    int cvc = int.Parse(txt3.Text);
                }
                catch (Exception ex)
                {
                    Console.Write("Please Enter the number......" + ex.Message);
                } 

                MessageBox.Show("your Payment is Successfully");
                Application.Exit(); */
            }
        }
    }
}
