﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }



        private void guna2Button2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Register_Click(object sender, EventArgs e)
        {

            if (!authenticate())
            {
                MessageBox.Show("form incomplete");
                return;
            }
            //encapsulation part
            CreateAcc c1 = new CreateAcc();
            String fname = tname.Text;
            String lname = Lname.Text;
            String address = taddress.Text;
            int num = int.Parse(tnum.Text);
            String email = temail.Text;
            String user = tuser.Text;
            String pass = tpass.Text;
            String rpass = trpass.Text;
            // set the variables for setters
            c1.setFname(fname);
            c1.setLname(lname);
            c1.setAddress(address);
            c1.setNum(num);
            c1.setEmail(email);
            c1.setUname(user);
            c1.setPassword(pass);
            c1.setRepassword(rpass);

            SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-49379LOU\SQLEXPRESS;Initial Catalog=PizzaDeliverySystem;Integrated Security=True");
            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[CustomerTable]
           ([first_name]
           ,[last_name]
           ,[address]
           ,[phone_number]
           ,[email]
           ,[user_name]
           ,[password]
           ,[re_password])
     VALUES
           ('" + c1.getFname() + "','" + c1.getLname() + "','" + c1.getAddress() + "','" + c1.getNumber() + "','" + c1.getEmail() + "','" + c1.getUname() + "','" + c1.getPassword() + "','" + c1.getRepassword() + "')", con);


            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Account Created\n " +
                "Username = '" + tuser.Text + "'\n Password = '" + tpass.Text + "'");
            ;
            //Form3 frm3 = new Form3();
            //frm3.Hide();
            Form1 frm1 = new Form1();
            frm1.Show();
            

        }

        bool authenticate()
        {
            if (string.IsNullOrWhiteSpace(tname.Text) ||
                string.IsNullOrWhiteSpace(Lname.Text) ||
                string.IsNullOrWhiteSpace(taddress.Text) ||
                string.IsNullOrWhiteSpace(tnum.Text) ||
                string.IsNullOrWhiteSpace(temail.Text) ||
                string.IsNullOrWhiteSpace(tuser.Text) ||
                string.IsNullOrWhiteSpace(tpass.Text) ||
                string.IsNullOrWhiteSpace(trpass.Text)

                )
                return false;
            else return true;

        }

        private void temail_TextChanged(object sender, EventArgs e)
        {
            System.Text.RegularExpressions.Regex rmail = new System.Text.RegularExpressions.Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([azA-Z]{2,4}|[0-9]{1,3})(\]?)$");
            if (temail.Text.Length > 0)
            {
                if (rmail.IsMatch(temail.Text))
                {

                    label9.ForeColor = Color.Green;
                    label9.Text = "";
                }
               /* else
                {
                    label9.ForeColor = Color.Red;
                    label9.Text = "Invalid email";
                    temail.Focus();
                    return;

                }*/
            }
        }

        private void trpass_TextChanged(object sender, EventArgs e)
        {
            if (trpass.Text == tpass.Text)
            {
                label10.ForeColor = Color.Green;
                label10.Text = "";
            }
            else
            {
                label10.ForeColor = Color.Red;
                label10.Text = "Password Not Matching";
            }
        }

        private void tnum_TextChanged(object sender, EventArgs e)
        {
            if (tnum.Text.Length == 10)
            {
                label11.ForeColor = Color.Green;
                label11.Text = "";
            }
            else
            {
                label11.ForeColor = Color.Red;
                label11.Text = "invalid mobile number";

            }
        }

        private void tuser_TextChanged(object sender, EventArgs e)
        {
            if (tuser.Text == "[Username]")
            {
                label12.Text = "Username not available";
                label12.ForeColor = Color.Red;

            }
            else
            {
                label12.Text = "available";
                label12.ForeColor = Color.Green;
            }
        }
    }

}
