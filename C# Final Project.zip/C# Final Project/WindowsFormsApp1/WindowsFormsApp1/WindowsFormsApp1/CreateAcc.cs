﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApp1
{
    class CreateAcc
    {
        private String efname, elname, eaddress, epass, erpass, eemail, euname;
        private int num;

        public void setFname(String efname)
        {
            this.efname = efname;
        }
        public void setLname(String elname)
        {
            this.elname = elname;
        }
        public void setAddress(String eaddress)
        {
            this.eaddress = eaddress;
        }
        public void setEmail(String eemail)
        {
            this.eemail = eemail;
        }
        public void setNum(int num)
        {
            this.num = num;
        }
        public void setUname(String euname)
        {
            this.euname = euname;
        }
        public void setPassword(String epass)
        {
            this.epass = epass;
        }
        public void setRepassword(String erpass)
        {
            this.erpass = erpass;
        }

        public String getFname()
        {
            return efname;
        }
        
        public String getLname()
        {
            return elname;
        }
        public String getAddress()
        {
            return eaddress;
        }
        public String getEmail()
        {
            return eemail;
        }
        public int getNumber()
        {
            return num;
        }
        public String getUname()
        {
            return euname;
        }
        public String getPassword()
        {
            return epass;
        }
        public String getRepassword()
        {
            return erpass;
        }

    }
}
