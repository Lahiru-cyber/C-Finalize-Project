﻿
namespace WindowsFormsApp1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.guna2ImageButton9 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton10 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton11 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton12 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton13 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton14 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton15 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton16 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton8 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton7 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton5 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton6 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton4 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton3 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton2 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton17 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton18 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton19 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2ImageButton20 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(324, 51);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(422, 38);
            this.guna2HtmlLabel1.TabIndex = 0;
            this.guna2HtmlLabel1.Text = "SELECT YOUR FAVORITE PIZZA ";
            // 
            // guna2Button1
            // 
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BorderRadius = 14;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.DisabledState.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.Red;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.IndicateFocus = true;
            this.guna2Button1.Location = new System.Drawing.Point(996, 12);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(127, 31);
            this.guna2Button1.TabIndex = 13;
            this.guna2Button1.Text = "Cancel";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Gainsboro;
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton9);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton10);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton11);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton12);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton13);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton14);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton15);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton16);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton8);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton7);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton1);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton5);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton6);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton4);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton3);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton2);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton17);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton18);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton19);
            this.flowLayoutPanel1.Controls.Add(this.guna2ImageButton20);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(30, 113);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1087, 565);
            this.flowLayoutPanel1.TabIndex = 55;
            // 
            // guna2ImageButton9
            // 
            this.guna2ImageButton9.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton9.CheckedState.Parent = this.guna2ImageButton9;
            this.guna2ImageButton9.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton9.HoverState.Parent = this.guna2ImageButton9;
            this.guna2ImageButton9.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton9.Image")));
            this.guna2ImageButton9.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton9.ImageRotate = 0F;
            this.guna2ImageButton9.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton9.Location = new System.Drawing.Point(3, 3);
            this.guna2ImageButton9.Name = "guna2ImageButton9";
            this.guna2ImageButton9.PressedState.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton9.PressedState.Parent = this.guna2ImageButton9;
            this.guna2ImageButton9.ShadowDecoration.Parent = this.guna2ImageButton9;
            this.guna2ImageButton9.Size = new System.Drawing.Size(243, 214);
            this.guna2ImageButton9.TabIndex = 69;
            this.guna2ImageButton9.Click += new System.EventHandler(this.guna2ImageButton9_Click_1);
            // 
            // guna2ImageButton10
            // 
            this.guna2ImageButton10.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton10.CheckedState.Parent = this.guna2ImageButton10;
            this.guna2ImageButton10.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton10.HoverState.Parent = this.guna2ImageButton10;
            this.guna2ImageButton10.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton10.Image")));
            this.guna2ImageButton10.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton10.ImageRotate = 0F;
            this.guna2ImageButton10.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton10.Location = new System.Drawing.Point(252, 3);
            this.guna2ImageButton10.Name = "guna2ImageButton10";
            this.guna2ImageButton10.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton10.PressedState.Parent = this.guna2ImageButton10;
            this.guna2ImageButton10.ShadowDecoration.Parent = this.guna2ImageButton10;
            this.guna2ImageButton10.Size = new System.Drawing.Size(227, 214);
            this.guna2ImageButton10.TabIndex = 68;
            this.guna2ImageButton10.Click += new System.EventHandler(this.guna2ImageButton10_Click_1);
            // 
            // guna2ImageButton11
            // 
            this.guna2ImageButton11.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton11.CheckedState.Parent = this.guna2ImageButton11;
            this.guna2ImageButton11.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton11.HoverState.Parent = this.guna2ImageButton11;
            this.guna2ImageButton11.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton11.Image")));
            this.guna2ImageButton11.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton11.ImageRotate = 0F;
            this.guna2ImageButton11.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton11.Location = new System.Drawing.Point(485, 3);
            this.guna2ImageButton11.Name = "guna2ImageButton11";
            this.guna2ImageButton11.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton11.PressedState.Parent = this.guna2ImageButton11;
            this.guna2ImageButton11.ShadowDecoration.Parent = this.guna2ImageButton11;
            this.guna2ImageButton11.Size = new System.Drawing.Size(240, 214);
            this.guna2ImageButton11.TabIndex = 67;
            this.guna2ImageButton11.Click += new System.EventHandler(this.guna2ImageButton11_Click);
            // 
            // guna2ImageButton12
            // 
            this.guna2ImageButton12.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton12.CheckedState.Parent = this.guna2ImageButton12;
            this.guna2ImageButton12.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton12.HoverState.Parent = this.guna2ImageButton12;
            this.guna2ImageButton12.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton12.Image")));
            this.guna2ImageButton12.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton12.ImageRotate = 0F;
            this.guna2ImageButton12.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton12.Location = new System.Drawing.Point(731, 3);
            this.guna2ImageButton12.Name = "guna2ImageButton12";
            this.guna2ImageButton12.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton12.PressedState.Parent = this.guna2ImageButton12;
            this.guna2ImageButton12.ShadowDecoration.Parent = this.guna2ImageButton12;
            this.guna2ImageButton12.Size = new System.Drawing.Size(249, 214);
            this.guna2ImageButton12.TabIndex = 66;
            // 
            // guna2ImageButton13
            // 
            this.guna2ImageButton13.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton13.CheckedState.Parent = this.guna2ImageButton13;
            this.guna2ImageButton13.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton13.HoverState.Parent = this.guna2ImageButton13;
            this.guna2ImageButton13.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton13.Image")));
            this.guna2ImageButton13.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton13.ImageRotate = 0F;
            this.guna2ImageButton13.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton13.Location = new System.Drawing.Point(3, 223);
            this.guna2ImageButton13.Name = "guna2ImageButton13";
            this.guna2ImageButton13.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton13.PressedState.Parent = this.guna2ImageButton13;
            this.guna2ImageButton13.ShadowDecoration.Parent = this.guna2ImageButton13;
            this.guna2ImageButton13.Size = new System.Drawing.Size(243, 200);
            this.guna2ImageButton13.TabIndex = 65;
            this.guna2ImageButton13.Click += new System.EventHandler(this.guna2ImageButton13_Click_1);
            // 
            // guna2ImageButton14
            // 
            this.guna2ImageButton14.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton14.CheckedState.Parent = this.guna2ImageButton14;
            this.guna2ImageButton14.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton14.HoverState.Parent = this.guna2ImageButton14;
            this.guna2ImageButton14.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton14.Image")));
            this.guna2ImageButton14.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton14.ImageRotate = 0F;
            this.guna2ImageButton14.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton14.Location = new System.Drawing.Point(252, 223);
            this.guna2ImageButton14.Name = "guna2ImageButton14";
            this.guna2ImageButton14.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton14.PressedState.Parent = this.guna2ImageButton14;
            this.guna2ImageButton14.ShadowDecoration.Parent = this.guna2ImageButton14;
            this.guna2ImageButton14.Size = new System.Drawing.Size(227, 200);
            this.guna2ImageButton14.TabIndex = 64;
            this.guna2ImageButton14.Click += new System.EventHandler(this.guna2ImageButton14_Click_1);
            // 
            // guna2ImageButton15
            // 
            this.guna2ImageButton15.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton15.CheckedState.Parent = this.guna2ImageButton15;
            this.guna2ImageButton15.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton15.HoverState.Parent = this.guna2ImageButton15;
            this.guna2ImageButton15.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton15.Image")));
            this.guna2ImageButton15.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton15.ImageRotate = 0F;
            this.guna2ImageButton15.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton15.Location = new System.Drawing.Point(485, 223);
            this.guna2ImageButton15.Name = "guna2ImageButton15";
            this.guna2ImageButton15.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton15.PressedState.Parent = this.guna2ImageButton15;
            this.guna2ImageButton15.ShadowDecoration.Parent = this.guna2ImageButton15;
            this.guna2ImageButton15.Size = new System.Drawing.Size(240, 200);
            this.guna2ImageButton15.TabIndex = 63;
            this.guna2ImageButton15.Click += new System.EventHandler(this.guna2ImageButton15_Click_1);
            // 
            // guna2ImageButton16
            // 
            this.guna2ImageButton16.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton16.CheckedState.Parent = this.guna2ImageButton16;
            this.guna2ImageButton16.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton16.HoverState.Parent = this.guna2ImageButton16;
            this.guna2ImageButton16.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton16.Image")));
            this.guna2ImageButton16.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton16.ImageRotate = 0F;
            this.guna2ImageButton16.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton16.Location = new System.Drawing.Point(731, 223);
            this.guna2ImageButton16.Name = "guna2ImageButton16";
            this.guna2ImageButton16.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton16.PressedState.Parent = this.guna2ImageButton16;
            this.guna2ImageButton16.ShadowDecoration.Parent = this.guna2ImageButton16;
            this.guna2ImageButton16.Size = new System.Drawing.Size(249, 200);
            this.guna2ImageButton16.TabIndex = 62;
            this.guna2ImageButton16.Click += new System.EventHandler(this.guna2ImageButton16_Click_1);
            // 
            // guna2ImageButton8
            // 
            this.guna2ImageButton8.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton8.CheckedState.Parent = this.guna2ImageButton8;
            this.guna2ImageButton8.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton8.HoverState.Parent = this.guna2ImageButton8;
            this.guna2ImageButton8.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton8.Image")));
            this.guna2ImageButton8.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton8.ImageRotate = 0F;
            this.guna2ImageButton8.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton8.Location = new System.Drawing.Point(3, 429);
            this.guna2ImageButton8.Name = "guna2ImageButton8";
            this.guna2ImageButton8.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton8.PressedState.Parent = this.guna2ImageButton8;
            this.guna2ImageButton8.ShadowDecoration.Parent = this.guna2ImageButton8;
            this.guna2ImageButton8.Size = new System.Drawing.Size(243, 206);
            this.guna2ImageButton8.TabIndex = 61;
            this.guna2ImageButton8.Click += new System.EventHandler(this.guna2ImageButton8_Click_1);
            // 
            // guna2ImageButton7
            // 
            this.guna2ImageButton7.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton7.CheckedState.Parent = this.guna2ImageButton7;
            this.guna2ImageButton7.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton7.HoverState.Parent = this.guna2ImageButton7;
            this.guna2ImageButton7.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton7.Image")));
            this.guna2ImageButton7.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton7.ImageRotate = 0F;
            this.guna2ImageButton7.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton7.Location = new System.Drawing.Point(252, 429);
            this.guna2ImageButton7.Name = "guna2ImageButton7";
            this.guna2ImageButton7.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton7.PressedState.Parent = this.guna2ImageButton7;
            this.guna2ImageButton7.ShadowDecoration.Parent = this.guna2ImageButton7;
            this.guna2ImageButton7.Size = new System.Drawing.Size(227, 206);
            this.guna2ImageButton7.TabIndex = 60;
            this.guna2ImageButton7.Click += new System.EventHandler(this.guna2ImageButton7_Click_1);
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.CheckedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton1.Image")));
            this.guna2ImageButton1.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton1.Location = new System.Drawing.Point(485, 429);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.PressedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.ShadowDecoration.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Size = new System.Drawing.Size(240, 206);
            this.guna2ImageButton1.TabIndex = 59;
            this.guna2ImageButton1.Click += new System.EventHandler(this.guna2ImageButton1_Click_1);
            // 
            // guna2ImageButton5
            // 
            this.guna2ImageButton5.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton5.CheckedState.Parent = this.guna2ImageButton5;
            this.guna2ImageButton5.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton5.HoverState.Parent = this.guna2ImageButton5;
            this.guna2ImageButton5.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton5.Image")));
            this.guna2ImageButton5.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton5.ImageRotate = 0F;
            this.guna2ImageButton5.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton5.Location = new System.Drawing.Point(731, 429);
            this.guna2ImageButton5.Name = "guna2ImageButton5";
            this.guna2ImageButton5.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton5.PressedState.Parent = this.guna2ImageButton5;
            this.guna2ImageButton5.ShadowDecoration.Parent = this.guna2ImageButton5;
            this.guna2ImageButton5.Size = new System.Drawing.Size(249, 206);
            this.guna2ImageButton5.TabIndex = 57;
            this.guna2ImageButton5.Click += new System.EventHandler(this.guna2ImageButton5_Click_1);
            // 
            // guna2ImageButton6
            // 
            this.guna2ImageButton6.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton6.CheckedState.Parent = this.guna2ImageButton6;
            this.guna2ImageButton6.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton6.HoverState.Parent = this.guna2ImageButton6;
            this.guna2ImageButton6.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton6.Image")));
            this.guna2ImageButton6.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton6.ImageRotate = 0F;
            this.guna2ImageButton6.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton6.Location = new System.Drawing.Point(3, 641);
            this.guna2ImageButton6.Name = "guna2ImageButton6";
            this.guna2ImageButton6.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton6.PressedState.Parent = this.guna2ImageButton6;
            this.guna2ImageButton6.ShadowDecoration.Parent = this.guna2ImageButton6;
            this.guna2ImageButton6.Size = new System.Drawing.Size(243, 210);
            this.guna2ImageButton6.TabIndex = 58;
            this.guna2ImageButton6.Click += new System.EventHandler(this.guna2ImageButton6_Click_1);
            // 
            // guna2ImageButton4
            // 
            this.guna2ImageButton4.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.CheckedState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.HoverState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton4.Image")));
            this.guna2ImageButton4.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton4.ImageRotate = 0F;
            this.guna2ImageButton4.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton4.Location = new System.Drawing.Point(252, 641);
            this.guna2ImageButton4.Name = "guna2ImageButton4";
            this.guna2ImageButton4.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton4.PressedState.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.ShadowDecoration.Parent = this.guna2ImageButton4;
            this.guna2ImageButton4.Size = new System.Drawing.Size(227, 210);
            this.guna2ImageButton4.TabIndex = 56;
            this.guna2ImageButton4.Click += new System.EventHandler(this.guna2ImageButton4_Click_1);
            // 
            // guna2ImageButton3
            // 
            this.guna2ImageButton3.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.CheckedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.HoverState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton3.Image")));
            this.guna2ImageButton3.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton3.ImageRotate = 0F;
            this.guna2ImageButton3.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton3.Location = new System.Drawing.Point(485, 641);
            this.guna2ImageButton3.Name = "guna2ImageButton3";
            this.guna2ImageButton3.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton3.PressedState.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.ShadowDecoration.Parent = this.guna2ImageButton3;
            this.guna2ImageButton3.Size = new System.Drawing.Size(240, 210);
            this.guna2ImageButton3.TabIndex = 55;
            this.guna2ImageButton3.Click += new System.EventHandler(this.guna2ImageButton3_Click_1);
            // 
            // guna2ImageButton2
            // 
            this.guna2ImageButton2.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.CheckedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.HoverState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton2.Image")));
            this.guna2ImageButton2.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton2.ImageRotate = 0F;
            this.guna2ImageButton2.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton2.Location = new System.Drawing.Point(731, 641);
            this.guna2ImageButton2.Name = "guna2ImageButton2";
            this.guna2ImageButton2.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.PressedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.ShadowDecoration.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Size = new System.Drawing.Size(249, 210);
            this.guna2ImageButton2.TabIndex = 54;
            this.guna2ImageButton2.Click += new System.EventHandler(this.guna2ImageButton2_Click_1);
            // 
            // guna2ImageButton17
            // 
            this.guna2ImageButton17.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton17.CheckedState.Parent = this.guna2ImageButton17;
            this.guna2ImageButton17.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton17.HoverState.Parent = this.guna2ImageButton17;
            this.guna2ImageButton17.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton17.Image")));
            this.guna2ImageButton17.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton17.ImageRotate = 0F;
            this.guna2ImageButton17.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton17.Location = new System.Drawing.Point(3, 857);
            this.guna2ImageButton17.Name = "guna2ImageButton17";
            this.guna2ImageButton17.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton17.PressedState.Parent = this.guna2ImageButton17;
            this.guna2ImageButton17.ShadowDecoration.Parent = this.guna2ImageButton17;
            this.guna2ImageButton17.Size = new System.Drawing.Size(243, 210);
            this.guna2ImageButton17.TabIndex = 73;
            this.guna2ImageButton17.Click += new System.EventHandler(this.guna2ImageButton17_Click);
            // 
            // guna2ImageButton18
            // 
            this.guna2ImageButton18.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton18.CheckedState.Parent = this.guna2ImageButton18;
            this.guna2ImageButton18.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton18.HoverState.Parent = this.guna2ImageButton18;
            this.guna2ImageButton18.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton18.Image")));
            this.guna2ImageButton18.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton18.ImageRotate = 0F;
            this.guna2ImageButton18.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton18.Location = new System.Drawing.Point(252, 857);
            this.guna2ImageButton18.Name = "guna2ImageButton18";
            this.guna2ImageButton18.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton18.PressedState.Parent = this.guna2ImageButton18;
            this.guna2ImageButton18.ShadowDecoration.Parent = this.guna2ImageButton18;
            this.guna2ImageButton18.Size = new System.Drawing.Size(227, 210);
            this.guna2ImageButton18.TabIndex = 72;
            this.guna2ImageButton18.Click += new System.EventHandler(this.guna2ImageButton18_Click);
            // 
            // guna2ImageButton19
            // 
            this.guna2ImageButton19.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton19.CheckedState.Parent = this.guna2ImageButton19;
            this.guna2ImageButton19.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton19.HoverState.Parent = this.guna2ImageButton19;
            this.guna2ImageButton19.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton19.Image")));
            this.guna2ImageButton19.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton19.ImageRotate = 0F;
            this.guna2ImageButton19.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton19.Location = new System.Drawing.Point(485, 857);
            this.guna2ImageButton19.Name = "guna2ImageButton19";
            this.guna2ImageButton19.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton19.PressedState.Parent = this.guna2ImageButton19;
            this.guna2ImageButton19.ShadowDecoration.Parent = this.guna2ImageButton19;
            this.guna2ImageButton19.Size = new System.Drawing.Size(240, 210);
            this.guna2ImageButton19.TabIndex = 71;
            this.guna2ImageButton19.Click += new System.EventHandler(this.guna2ImageButton19_Click);
            // 
            // guna2ImageButton20
            // 
            this.guna2ImageButton20.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton20.CheckedState.Parent = this.guna2ImageButton20;
            this.guna2ImageButton20.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton20.HoverState.Parent = this.guna2ImageButton20;
            this.guna2ImageButton20.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton20.Image")));
            this.guna2ImageButton20.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton20.ImageRotate = 0F;
            this.guna2ImageButton20.ImageSize = new System.Drawing.Size(230, 230);
            this.guna2ImageButton20.Location = new System.Drawing.Point(731, 857);
            this.guna2ImageButton20.Name = "guna2ImageButton20";
            this.guna2ImageButton20.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton20.PressedState.Parent = this.guna2ImageButton20;
            this.guna2ImageButton20.ShadowDecoration.Parent = this.guna2ImageButton20;
            this.guna2ImageButton20.Size = new System.Drawing.Size(249, 210);
            this.guna2ImageButton20.TabIndex = 70;
            this.guna2ImageButton20.Click += new System.EventHandler(this.guna2ImageButton20_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1129, 701);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton9;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton10;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton11;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton12;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton13;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton14;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton15;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton16;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton8;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton7;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton5;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton6;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton4;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton3;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton2;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton17;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton18;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton19;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton20;
    }
}