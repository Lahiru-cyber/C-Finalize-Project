﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            populate();
        }

        private void reset()
        {
            guna2TextBox1.ResetText();
            guna2TextBox2.ResetText();
            guna2TextBox3.ResetText();
            guna2TextBox4.ResetText();
            guna2TextBox5.ResetText();
            guna2TextBox6.ResetText();
            guna2TextBox7.ResetText();
            guna2TextBox8.ResetText();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            if (guna2TextBox1.Text == "" || guna2TextBox2.Text == "" || guna2TextBox3.Text == "" || guna2TextBox4.Text == "" || guna2TextBox5.Text == "" || guna2TextBox6.Text == "" || guna2TextBox7.Text == "" || guna2TextBox8.Text == "")
            MessageBox.Show("Please fill all fileds", "Error",MessageBoxButtons.OK, MessageBoxIcon.Error);

            else

            {

                SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-49379LOU\SQLEXPRESS;Initial Catalog=PizzaDeliverySystem;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO  dbo.[CustomerTable](first_name,last_name,address,phone_number,email,user_name,password,re_password) " + " VALUES ('" + guna2TextBox1.Text + "','" + guna2TextBox2.Text + "','" + guna2TextBox4 + "','" + guna2TextBox5.Text + "','" + guna2TextBox3.Text + "','" + guna2TextBox6.Text + "','" + guna2TextBox7.Text + "','" + guna2TextBox8.Text + "')", con);
                int i = cmd.ExecuteNonQuery();
                

                if (i != 0)

                {

                    MessageBox.Show("Data saved", "ok");
                    populate();
                    reset();


                }

                else

                {

                    MessageBox.Show("Data not saved", "No");


                }


            }
        }
        
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-49379LOU\SQLEXPRESS;Initial Catalog=PizzaDeliverySystem;Integrated Security=True");

        private void populate()
        {
            con.Open();
            string query = "SELECT * FROM CustomerTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            guna2TextBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            guna2TextBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            guna2TextBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            guna2TextBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            guna2TextBox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            guna2TextBox6.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            guna2TextBox7.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            guna2TextBox8.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if(guna2TextBox1.Text == "")
                {
                    MessageBox.Show("Select the row to delete");
                }
                else
                {
                    con.Open();
                    string query = "DELETE FROM CustomerTable where phone_number='" + guna2TextBox5.Text + "' ";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Row Deleted Successfully");
                    con.Close();
                    populate();
                    reset();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (guna2TextBox1.Text == "")
                {
                    MessageBox.Show("Select the row to update");
                }
                else
                {
                    con.Open();
                    string query = "UPDATE CustomerTable SET phone_number = '" + guna2TextBox7.Text + "' WHERE first_name = '" + guna2TextBox1 + "'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Row Updated Successfully");
                    con.Close();
                    populate();
                    reset();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
