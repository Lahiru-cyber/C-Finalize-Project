﻿
namespace WindowsFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tuser = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.Register = new Guna.UI2.WinForms.Guna2Button();
            this.trpass = new Guna.UI2.WinForms.Guna2TextBox();
            this.tpass = new Guna.UI2.WinForms.Guna2TextBox();
            this.temail = new Guna.UI2.WinForms.Guna2TextBox();
            this.tnum = new Guna.UI2.WinForms.Guna2TextBox();
            this.taddress = new Guna.UI2.WinForms.Guna2TextBox();
            this.Lname = new Guna.UI2.WinForms.Guna2TextBox();
            this.tname = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.guna2Panel1.Controls.Add(this.label12);
            this.guna2Panel1.Controls.Add(this.label11);
            this.guna2Panel1.Controls.Add(this.label10);
            this.guna2Panel1.Controls.Add(this.label9);
            this.guna2Panel1.Controls.Add(this.label8);
            this.guna2Panel1.Controls.Add(this.tuser);
            this.guna2Panel1.Controls.Add(this.label7);
            this.guna2Panel1.Controls.Add(this.label6);
            this.guna2Panel1.Controls.Add(this.label5);
            this.guna2Panel1.Controls.Add(this.label4);
            this.guna2Panel1.Controls.Add(this.label3);
            this.guna2Panel1.Controls.Add(this.label2);
            this.guna2Panel1.Controls.Add(this.label1);
            this.guna2Panel1.Controls.Add(this.guna2Button2);
            this.guna2Panel1.Controls.Add(this.Register);
            this.guna2Panel1.Controls.Add(this.trpass);
            this.guna2Panel1.Controls.Add(this.tpass);
            this.guna2Panel1.Controls.Add(this.temail);
            this.guna2Panel1.Controls.Add(this.tnum);
            this.guna2Panel1.Controls.Add(this.taddress);
            this.guna2Panel1.Controls.Add(this.Lname);
            this.guna2Panel1.Controls.Add(this.tname);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel8);
            this.guna2Panel1.Location = new System.Drawing.Point(12, 12);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(1053, 672);
            this.guna2Panel1.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(200, 546);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(12, 17);
            this.label12.TabIndex = 73;
            this.label12.Text = ".";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(685, 342);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(12, 17);
            this.label11.TabIndex = 72;
            this.label11.Text = ".";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(685, 535);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(12, 17);
            this.label10.TabIndex = 71;
            this.label10.Text = ".";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(196, 442);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(12, 17);
            this.label9.TabIndex = 70;
            this.label9.Text = ".";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label8.Location = new System.Drawing.Point(191, 464);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 25);
            this.label8.TabIndex = 69;
            this.label8.Text = "Username";
            // 
            // tuser
            // 
            this.tuser.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tuser.DefaultText = "";
            this.tuser.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tuser.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tuser.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tuser.DisabledState.Parent = this.tuser;
            this.tuser.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tuser.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tuser.FocusedState.Parent = this.tuser;
            this.tuser.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tuser.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tuser.HoverState.Parent = this.tuser;
            this.tuser.Location = new System.Drawing.Point(196, 492);
            this.tuser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tuser.Name = "tuser";
            this.tuser.PasswordChar = '\0';
            this.tuser.PlaceholderText = "";
            this.tuser.SelectedText = "";
            this.tuser.ShadowDecoration.Parent = this.tuser;
            this.tuser.Size = new System.Drawing.Size(325, 36);
            this.tuser.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.tuser.TabIndex = 68;
            this.tuser.TextChanged += new System.EventHandler(this.tuser_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label7.Location = new System.Drawing.Point(191, 370);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 25);
            this.label7.TabIndex = 67;
            this.label7.Text = "Email";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label6.Location = new System.Drawing.Point(677, 464);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 25);
            this.label6.TabIndex = 66;
            this.label6.Text = "Re-Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label5.Location = new System.Drawing.Point(677, 370);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 25);
            this.label5.TabIndex = 65;
            this.label5.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label4.Location = new System.Drawing.Point(677, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 25);
            this.label4.TabIndex = 64;
            this.label4.Text = "Phone Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label3.Location = new System.Drawing.Point(191, 265);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 25);
            this.label3.TabIndex = 63;
            this.label3.Text = "Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label2.Location = new System.Drawing.Point(677, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 25);
            this.label2.TabIndex = 62;
            this.label2.Text = "Last Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(191, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 25);
            this.label1.TabIndex = 61;
            this.label1.Text = "First Name";
            // 
            // guna2Button2
            // 
            this.guna2Button2.Animated = true;
            this.guna2Button2.AutoRoundedCorners = true;
            this.guna2Button2.BorderRadius = 22;
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.DisabledState.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.Red;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.IndicateFocus = true;
            this.guna2Button2.Location = new System.Drawing.Point(831, 585);
            this.guna2Button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(180, 46);
            this.guna2Button2.TabIndex = 53;
            this.guna2Button2.Text = "Cancel";
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click_1);
            // 
            // Register
            // 
            this.Register.Animated = true;
            this.Register.AutoRoundedCorners = true;
            this.Register.BorderRadius = 22;
            this.Register.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            this.Register.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            this.Register.CheckedState.Parent = this.Register;
            this.Register.CustomImages.Parent = this.Register;
            this.Register.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Register.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Register.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Register.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Register.DisabledState.Parent = this.Register;
            this.Register.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.Register.ForeColor = System.Drawing.Color.White;
            this.Register.HoverState.Parent = this.Register;
            this.Register.IndicateFocus = true;
            this.Register.Location = new System.Drawing.Point(629, 585);
            this.Register.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Register.Name = "Register";
            this.Register.ShadowDecoration.Parent = this.Register;
            this.Register.Size = new System.Drawing.Size(180, 46);
            this.Register.TabIndex = 52;
            this.Register.Text = "Register";
            this.Register.Click += new System.EventHandler(this.Register_Click);
            // 
            // trpass
            // 
            this.trpass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.trpass.DefaultText = "";
            this.trpass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.trpass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.trpass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.trpass.DisabledState.Parent = this.trpass;
            this.trpass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.trpass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.trpass.FocusedState.Parent = this.trpass;
            this.trpass.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.trpass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.trpass.HoverState.Parent = this.trpass;
            this.trpass.Location = new System.Drawing.Point(683, 492);
            this.trpass.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.trpass.Name = "trpass";
            this.trpass.PasswordChar = '*';
            this.trpass.PlaceholderText = "";
            this.trpass.SelectedText = "";
            this.trpass.ShadowDecoration.Parent = this.trpass;
            this.trpass.Size = new System.Drawing.Size(325, 36);
            this.trpass.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.trpass.TabIndex = 50;
            this.trpass.TextChanged += new System.EventHandler(this.trpass_TextChanged);
            // 
            // tpass
            // 
            this.tpass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tpass.DefaultText = "";
            this.tpass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tpass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tpass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tpass.DisabledState.Parent = this.tpass;
            this.tpass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tpass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tpass.FocusedState.Parent = this.tpass;
            this.tpass.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tpass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tpass.HoverState.Parent = this.tpass;
            this.tpass.Location = new System.Drawing.Point(683, 399);
            this.tpass.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpass.Name = "tpass";
            this.tpass.PasswordChar = '*';
            this.tpass.PlaceholderText = "";
            this.tpass.SelectedText = "";
            this.tpass.ShadowDecoration.Parent = this.tpass;
            this.tpass.Size = new System.Drawing.Size(325, 36);
            this.tpass.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.tpass.TabIndex = 49;
            // 
            // temail
            // 
            this.temail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.temail.DefaultText = "";
            this.temail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.temail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.temail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.temail.DisabledState.Parent = this.temail;
            this.temail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.temail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.temail.FocusedState.Parent = this.temail;
            this.temail.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.temail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.temail.HoverState.Parent = this.temail;
            this.temail.Location = new System.Drawing.Point(196, 399);
            this.temail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.temail.Name = "temail";
            this.temail.PasswordChar = '\0';
            this.temail.PlaceholderText = "";
            this.temail.SelectedText = "";
            this.temail.ShadowDecoration.Parent = this.temail;
            this.temail.Size = new System.Drawing.Size(355, 36);
            this.temail.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.temail.TabIndex = 48;
            this.temail.TextChanged += new System.EventHandler(this.temail_TextChanged);
            // 
            // tnum
            // 
            this.tnum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tnum.DefaultText = "";
            this.tnum.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tnum.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tnum.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tnum.DisabledState.Parent = this.tnum;
            this.tnum.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tnum.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tnum.FocusedState.Parent = this.tnum;
            this.tnum.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tnum.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tnum.HoverState.Parent = this.tnum;
            this.tnum.Location = new System.Drawing.Point(685, 304);
            this.tnum.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tnum.Name = "tnum";
            this.tnum.PasswordChar = '\0';
            this.tnum.PlaceholderText = "";
            this.tnum.SelectedText = "";
            this.tnum.ShadowDecoration.Parent = this.tnum;
            this.tnum.Size = new System.Drawing.Size(325, 36);
            this.tnum.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.tnum.TabIndex = 47;
            this.tnum.TextChanged += new System.EventHandler(this.tnum_TextChanged);
            // 
            // taddress
            // 
            this.taddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.taddress.DefaultText = "";
            this.taddress.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.taddress.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.taddress.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.taddress.DisabledState.Parent = this.taddress;
            this.taddress.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.taddress.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.taddress.FocusedState.Parent = this.taddress;
            this.taddress.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.taddress.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.taddress.HoverState.Parent = this.taddress;
            this.taddress.Location = new System.Drawing.Point(196, 304);
            this.taddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.taddress.Name = "taddress";
            this.taddress.PasswordChar = '\0';
            this.taddress.PlaceholderText = "";
            this.taddress.SelectedText = "";
            this.taddress.ShadowDecoration.Parent = this.taddress;
            this.taddress.Size = new System.Drawing.Size(355, 36);
            this.taddress.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.taddress.TabIndex = 46;
            // 
            // Lname
            // 
            this.Lname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Lname.DefaultText = "";
            this.Lname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Lname.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Lname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Lname.DisabledState.Parent = this.Lname;
            this.Lname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Lname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Lname.FocusedState.Parent = this.Lname;
            this.Lname.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Lname.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Lname.HoverState.Parent = this.Lname;
            this.Lname.Location = new System.Drawing.Point(683, 203);
            this.Lname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Lname.Name = "Lname";
            this.Lname.PasswordChar = '\0';
            this.Lname.PlaceholderText = "";
            this.Lname.SelectedText = "";
            this.Lname.ShadowDecoration.Parent = this.Lname;
            this.Lname.Size = new System.Drawing.Size(325, 36);
            this.Lname.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.Lname.TabIndex = 45;
            // 
            // tname
            // 
            this.tname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tname.DefaultText = "";
            this.tname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tname.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tname.DisabledState.Parent = this.tname;
            this.tname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tname.FocusedState.Parent = this.tname;
            this.tname.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tname.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tname.HoverState.Parent = this.tname;
            this.tname.Location = new System.Drawing.Point(196, 203);
            this.tname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tname.Name = "tname";
            this.tname.PasswordChar = '\0';
            this.tname.PlaceholderText = "";
            this.tname.SelectedText = "";
            this.tname.ShadowDecoration.Parent = this.tname;
            this.tname.Size = new System.Drawing.Size(355, 36);
            this.tname.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.tname.TabIndex = 44;
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.ForeColor = System.Drawing.SystemColors.GrayText;
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(387, 26);
            this.guna2HtmlLabel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(239, 33);
            this.guna2HtmlLabel8.TabIndex = 43;
            this.guna2HtmlLabel8.Text = "Join With US . . . .";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1077, 697);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button Register;
        private Guna.UI2.WinForms.Guna2TextBox trpass;
        private Guna.UI2.WinForms.Guna2TextBox tpass;
        private Guna.UI2.WinForms.Guna2TextBox temail;
        private Guna.UI2.WinForms.Guna2TextBox tnum;
        private Guna.UI2.WinForms.Guna2TextBox taddress;
        private Guna.UI2.WinForms.Guna2TextBox Lname;
        private Guna.UI2.WinForms.Guna2TextBox tname;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2TextBox tuser;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}