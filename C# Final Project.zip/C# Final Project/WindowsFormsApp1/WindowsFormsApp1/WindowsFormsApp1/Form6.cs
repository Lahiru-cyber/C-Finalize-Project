﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your order will be receive in 30 minutes to your doorstep.");
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Form6 frm6 = new Form6();
            this.Hide();
            Form7 frm7 = new Form7();
            frm7.Show();

        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


    }
}
