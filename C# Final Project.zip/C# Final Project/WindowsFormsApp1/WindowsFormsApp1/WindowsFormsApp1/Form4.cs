﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void paymentMethod()
        {
            Form6 form6 = new Form6();
            form6.Show();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void vsbar_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void guna2ImageButton17_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.500/-");
            paymentMethod();
        }

        private void guna2ImageButton18_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.500/-");
            paymentMethod();
        }

        private void guna2ImageButton19_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.500/-");
            paymentMethod();
        }

        private void guna2ImageButton20_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.500/-");
            paymentMethod();
        }

        private void guna2ImageButton9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.600/-");
            paymentMethod();
        }

        private void guna2ImageButton10_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.750/-");
            paymentMethod();
        }

        private void guna2ImageButton11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.550/-");
            paymentMethod();
        }

        private void guna2ImageButton12_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.570/-");
            paymentMethod();
        }

        private void guna2ImageButton13_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.950/-");
            paymentMethod();
        }

        private void guna2ImageButton14_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.1200/-");
            paymentMethod();
        }

        private void guna2ImageButton15_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.1100/-");
            paymentMethod();
        }

        private void guna2ImageButton16_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.990/-");
            paymentMethod();
        }

        private void guna2ImageButton8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.2100/-");
            paymentMethod();
        }

        private void guna2ImageButton7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.950/-");
            paymentMethod();
        }

        private void guna2ImageButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.850/-");
            paymentMethod();
        }

        private void guna2ImageButton5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.510/-");
            paymentMethod();
        }

        private void guna2ImageButton6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.990/-");
            paymentMethod();
        }

        private void guna2ImageButton4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.600/-");
            paymentMethod();
        }

        private void guna2ImageButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.1500/-");
            paymentMethod();
        }

        private void guna2ImageButton2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.800/-");
            paymentMethod();
        }

        private void guna2ImageButton9_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.860/-");
            paymentMethod();
        }

        private void guna2ImageButton10_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.800/-");
            paymentMethod();
        }

        private void guna2ImageButton15_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.850/-");
            paymentMethod();
        }

        private void guna2ImageButton8_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.650/-");
            paymentMethod();
        }

        private void guna2ImageButton1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.950/-");
            paymentMethod();
        }

        private void guna2ImageButton16_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.750/-");
            paymentMethod();
        }

        private void guna2ImageButton13_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.450/-");
            paymentMethod();
        }

        private void guna2ImageButton14_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.1250/-");
            paymentMethod();
        }

        private void guna2ImageButton7_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.1650/-");
            paymentMethod();
        }

        private void guna2ImageButton5_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.1235/-");
            paymentMethod();
        }

        private void guna2ImageButton6_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.2500/-");
            paymentMethod();
        }

        private void guna2ImageButton4_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.950/-");
            paymentMethod();
        }

        private void guna2ImageButton3_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.1000/-");
            paymentMethod();
        }

        private void guna2ImageButton2_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Rs.1420/-");
            paymentMethod();
        }
    }
}
