﻿
namespace WindowsFormsApp1
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.txt1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.next = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txt1
            // 
            this.txt1.BorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt1.DefaultText = "";
            this.txt1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt1.DisabledState.Parent = this.txt1;
            this.txt1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt1.FocusedState.Parent = this.txt1;
            this.txt1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt1.HoverState.Parent = this.txt1;
            this.txt1.Location = new System.Drawing.Point(94, 188);
            this.txt1.Name = "txt1";
            this.txt1.PasswordChar = '\0';
            this.txt1.PlaceholderForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt1.PlaceholderText = "Card Number";
            this.txt1.SelectedText = "";
            this.txt1.ShadowDecoration.Parent = this.txt1;
            this.txt1.Size = new System.Drawing.Size(289, 36);
            this.txt1.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txt1.TabIndex = 69;
            // 
            // txt2
            // 
            this.txt2.BorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt2.DefaultText = "";
            this.txt2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt2.DisabledState.Parent = this.txt2;
            this.txt2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt2.FocusedState.Parent = this.txt2;
            this.txt2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt2.HoverState.Parent = this.txt2;
            this.txt2.Location = new System.Drawing.Point(549, 188);
            this.txt2.Name = "txt2";
            this.txt2.PasswordChar = '\0';
            this.txt2.PlaceholderForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt2.PlaceholderText = "Expiry Date";
            this.txt2.SelectedText = "";
            this.txt2.ShadowDecoration.Parent = this.txt2;
            this.txt2.Size = new System.Drawing.Size(289, 36);
            this.txt2.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txt2.TabIndex = 70;
            // 
            // txt3
            // 
            this.txt3.BorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt3.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.txt3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt3.DefaultText = "";
            this.txt3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt3.DisabledState.Parent = this.txt3;
            this.txt3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt3.FocusedState.Parent = this.txt3;
            this.txt3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt3.HoverState.Parent = this.txt3;
            this.txt3.Location = new System.Drawing.Point(94, 287);
            this.txt3.Name = "txt3";
            this.txt3.PasswordChar = '\0';
            this.txt3.PlaceholderForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt3.PlaceholderText = "CVC";
            this.txt3.SelectedText = "";
            this.txt3.ShadowDecoration.Parent = this.txt3;
            this.txt3.Size = new System.Drawing.Size(289, 36);
            this.txt3.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txt3.TabIndex = 71;
            this.txt3.UseSystemPasswordChar = true;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(263, 363);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(447, 81);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 72;
            this.guna2PictureBox1.TabStop = false;
            // 
            // next
            // 
            this.next.Animated = true;
            this.next.AutoRoundedCorners = true;
            this.next.BorderRadius = 24;
            this.next.CheckedState.Parent = this.next;
            this.next.CustomImages.Parent = this.next;
            this.next.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.next.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.next.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.next.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.next.DisabledState.Parent = this.next;
            this.next.FillColor = System.Drawing.SystemColors.ActiveBorder;
            this.next.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.next.ForeColor = System.Drawing.Color.White;
            this.next.HoverState.Parent = this.next;
            this.next.IndicateFocus = true;
            this.next.Location = new System.Drawing.Point(94, 472);
            this.next.Name = "next";
            this.next.ShadowDecoration.Parent = this.next;
            this.next.Size = new System.Drawing.Size(806, 50);
            this.next.TabIndex = 73;
            this.next.Text = "NEXT";
            this.next.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(253, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(457, 32);
            this.label1.TabIndex = 74;
            this.label1.Text = "CARD PAYMENT DETAILS . . . . ";
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1000, 598);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.next);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form7";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form7";
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI2.WinForms.Guna2TextBox txt1;
        private Guna.UI2.WinForms.Guna2TextBox txt2;
        private Guna.UI2.WinForms.Guna2TextBox txt3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Button next;
        private System.Windows.Forms.Label label1;
    }
}