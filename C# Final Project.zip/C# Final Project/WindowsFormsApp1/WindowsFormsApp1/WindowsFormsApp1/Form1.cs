﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static Form1 instance;
        public Form1()
        {
            InitializeComponent();
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
             Form1 frm = new Form1();
             this.Hide();
             Form3 frm3 = new Form3();
             frm3.Show(); 

           


        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            String role = combo.Text;
            String uname = txt1.Text;
            String pass = txt2.Text;
            if(role == "Admin ")
            {
                if (uname == "Admin" && pass == "1234")
                {
                    Form1 frm = new Form1();
                    this.Hide();
                    Form5 frm5 = new Form5();
                    frm5.Show();
                }
            }
            else if(role == "Member")
            {
                if (uname == "member" && pass == "12345")
                {
                    Form1 frm = new Form1();
                    this.Hide();
                    Form4 frm4 = new Form4();
                    frm4.Show();
                }
                else
                {
                    MessageBox.Show("Incorrect name or password!!!");
                }
            }
            else
            {
                MessageBox.Show("Select role");
            }
            
            
            

        }
    }
}
